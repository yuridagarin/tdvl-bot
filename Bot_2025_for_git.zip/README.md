# Discord Bot

Đây là một bot Discord mẫu sử dụng `discord.py`.

## Hướng dẫn chạy:
1. Tạo file `.env` và thêm token:
```
DISCORD_TOKEN=your-real-token
```
2. Cài thư viện:
```
pip install -r requirements.txt
```
3. Chạy bot:
```
python main.py
```
#   t d v l - b o t  
 