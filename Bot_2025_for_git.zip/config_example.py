# Ví dụ config
TOKEN = 'your-token-here'
PREFIX = '!'
